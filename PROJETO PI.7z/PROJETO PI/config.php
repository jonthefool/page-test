<?php
$host = "localhost";
$user = "root"; // Usuário padrão do XAMPP
$pass = ""; // Senha padrão (vazia)
$db = "meu_projeto";

// Criar conexão com MySQL
$conn = new mysqli($host, $user, $pass, $db);

// Verificar se houve erro na conexão
if ($conn->connect_error) {
    die("Erro na conexão: " . $conn->connect_error);
}
?>
