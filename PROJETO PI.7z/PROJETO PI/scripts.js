async function carregarUsuarios() {
    const resposta = await fetch("http://localhost/meu_projeto/listar_usuarios.php");
    const usuarios = await resposta.json();
    const lista = document.getElementById("listaUsuarios");
    lista.innerHTML = "";
    usuarios.forEach(user => {
        const item = document.createElement("li");
        item.textContent = `${user.nome} - ${user.email}`;
        lista.appendChild(item);
    });
}

async function adicionarUsuario() {
    const nome = document.getElementById("nome").value;
    const email = document.getElementById("email").value;

    await fetch("http://localhost/meu_projeto/adicionar_usuario.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nome, email })
    });

    carregarUsuarios();
}

carregarUsuarios();