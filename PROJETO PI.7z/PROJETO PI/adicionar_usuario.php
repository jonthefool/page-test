<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

include "config.php";

$data = json_decode(file_get_contents("php://input"), true);

$nome = $data["nome"] ?? "";
$email = $data["email"] ?? "";

// Impedir inserção de valores vazios
if (empty($nome) || empty($email)) {
    echo json_encode(["error" => "Nome e email são obrigatórios"]);
    exit();
}

$sql = "INSERT INTO usuarios (nome, email) VALUES ('$nome', '$email')";
if ($conn->query($sql)) {
    echo json_encode(["message" => "Usuário criado!", "id" => $conn->insert_id]);
} else {
    echo json_encode(["error" => "Erro ao inserir usuário: " . $conn->error]);
}
?>
